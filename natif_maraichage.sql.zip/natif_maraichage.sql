-- phpMyAdmin SQL Dump
-- version 4.6.6deb4
-- https://www.phpmyadmin.net/
--
-- Client :  localhost:3306
-- Généré le :  Ven 08 Mars 2019 à 18:18
-- Version du serveur :  10.1.37-MariaDB-0+deb9u1
-- Version de PHP :  7.2.14-1+0~20190113100742.14+stretch~1.gbpd83c69

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `natif_maraichage`
--

-- --------------------------------------------------------

--
-- Structure de la table `legume`
--

CREATE TABLE `legume` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `variete` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `legume`
--

INSERT INTO `legume` (`id`, `name`, `variete`) VALUES
(1, 'Tomate', 'Solanacées'),
(2, 'Concombre', 'cucurbitacées'),
(3, 'Poireaux', 'cucurbitacées');

-- --------------------------------------------------------

--
-- Structure de la table `planche`
--

CREATE TABLE `planche` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `planche`
--

INSERT INTO `planche` (`id`, `name`) VALUES
(1, 'planche 1'),
(2, 'planche 2');

-- --------------------------------------------------------

--
-- Structure de la table `rotation`
--

CREATE TABLE `rotation` (
  `id` int(10) UNSIGNED NOT NULL,
  `zone` varchar(100) NOT NULL,
  `number_serre` varchar(100) DEFAULT NULL,
  `number_planche` varchar(100) DEFAULT NULL,
  `legume` varchar(100) NOT NULL,
  `tache` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `serre`
--

CREATE TABLE `serre` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `number_planche` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `serre`
--

INSERT INTO `serre` (`id`, `name`, `number_planche`) VALUES
(1, 'Serre 1', 7),
(2, 'Serre 2', 7),
(3, 'Serre 3', 6);

-- --------------------------------------------------------

--
-- Structure de la table `tache`
--

CREATE TABLE `tache` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `tache`
--

INSERT INTO `tache` (`id`, `name`) VALUES
(1, 'Semis'),
(2, 'Rempotage'),
(3, 'Transplantation'),
(4, 'Preparation'),
(5, 'Couvert'),
(6, 'Tuteurage'),
(7, 'Taille'),
(8, 'Traitement'),
(9, 'Récolte');

-- --------------------------------------------------------

--
-- Structure de la table `zone`
--

CREATE TABLE `zone` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `zone`
--

INSERT INTO `zone` (`id`, `name`) VALUES
(1, 'Jardin'),
(2, 'Serre'),
(3, 'Pépinière'),
(4, 'Plein champs'),
(5, 'Divers');

--
-- Index pour les tables exportées
--

--
-- Index pour la table `legume`
--
ALTER TABLE `legume`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `planche`
--
ALTER TABLE `planche`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `rotation`
--
ALTER TABLE `rotation`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `serre`
--
ALTER TABLE `serre`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `tache`
--
ALTER TABLE `tache`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `zone`
--
ALTER TABLE `zone`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `legume`
--
ALTER TABLE `legume`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `planche`
--
ALTER TABLE `planche`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `rotation`
--
ALTER TABLE `rotation`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `serre`
--
ALTER TABLE `serre`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `tache`
--
ALTER TABLE `tache`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT pour la table `zone`
--
ALTER TABLE `zone`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
